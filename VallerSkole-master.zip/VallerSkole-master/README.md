# Valler Skole
The python notebook is self-explanatory

You will need to install the:
1) Logging
2) PlotLy
3) Pandas dataframe
4) Cufflinks
